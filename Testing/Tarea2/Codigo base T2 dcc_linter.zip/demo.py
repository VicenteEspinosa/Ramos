from ast import *

if True:
    x = 1
else:
    pass





