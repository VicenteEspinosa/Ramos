class Person:

    def fullName(self):
        return self.firstName + self.lastName