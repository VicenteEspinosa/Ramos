from flask import Flask, render_template, request, abort, json
from pymongo import MongoClient
import pandas as pd
import matplotlib.pyplot as plt
import os
import random



USER = "grupo96"
PASS = "grupo96"
DATABASE = "grupo96"

# El cliente se levanta en la URL de la wiki
# URL = "mongodb://grupoXX:grupoXX@gray.ing.puc.cl/grupoXX"
URL = f"mongodb://{USER}:{PASS}@gray.ing.puc.cl/{DATABASE}"
client = MongoClient(URL)

# Utilizamos la base de datos del grupo
db = client["grupo96"]

# Seleccionamos la collección de usuarios y mensajes
usuarios = db.users
mensajes = db.messages


# Iniciamos la aplicación de flask
app = Flask(__name__)

@app.route("/")
def home():
    '''
    Página de inicio
    '''
    return "<h1>¡Hola!</h1>"


@app.route("/users")
def get_users():
    '''
    Obtiene todos los usuarios
    '''
    # Omitir el _id porque no es json serializable
    resultados = list(usuarios.find({}, {"_id": 0}))
    return json.jsonify(resultados)


@app.route("/users/<int:uid>")
def get_user(uid):
    '''
    Obtiene el usuario de id entregada
    '''
    users = list(usuarios.find({"uid": uid}, {"_id": 0}))
    if len(users) == 0:
        return "<h1>El usuario que esta buscando no existe.</h1>"
    if json.jsonify(users):
        return json.jsonify(users)


@app.route("/messages")
def get_messages():
    '''
    Obtiene todos los mensajes
    '''
    # Omitir el _id porque no es json serializable
    uid1 = request.args.get("id1", type= int)
    uid2 = request.args.get("id2", type= int)

    if uid1 and uid2:
        print(uid1)
        print(uid2)

        resultados1 = list(mensajes.find({"sender": uid1, "receptant": uid2}, {"_id": 0}))
        resultados2 = list(mensajes.find({"sender": uid2, "receptant": uid1}, {"_id": 0}))
        resultado = resultados1 + resultados2

        if len(resultado) == 0:
            return "<h1>Entrego uno 0 mas id's invalido</h1>"


        return json.jsonify(resultado)


    resultados = list(mensajes.find({}, {"_id": 0}))
    return json.jsonify(resultados)


@app.route("/message/<int:mensajeid>",methods=['DELETE'])
def delete_message(mensajeid):

    buscar_mensaje = list(mensajes.find({"mid": mensajeid}, {"_id": 0}))
    if len(buscar_mensaje) > 0 :
        eliminar = mensajes.delete_one({'mid' : mensajeid })
        return "<h1>Mensaje eliminado</h1>"

    else:
        return "<h1>Mensaje no existe</h1>"



@app.route("/text-search", methods=['GET'])
def get_the_message():
    desired = False
    required = False
    forbidden = False
    userid = False
    '''
    Obtiene la request
    '''
    buscar = request.get_json()
    query = str()
    if 'desired' in buscar:
        desired = buscar['desired'] #es una lista
        for frase in desired:
            query += frase + " "

    if 'required' in buscar:
        required = buscar['required'] #es una lista
        for frase in required:
            query += '\"{}\"'.format(frase)

    if 'forbidden' in buscar:
        forbidden = buscar['forbidden'] #es una lista
        for frase in forbidden:
            query += " -{}".format(frase)
            query += " "

    query = query.strip(",")
    query = query.strip()
    query = "'{}'".format(query)


    if 'userId' in buscar:
        userid = buscar['userId']
        if not(desired == False) or not(required == False):
            qand = list(mensajes.find({'$and': [{"sender": int(userid)},{"$text":{"$search": query}}]}))
            return str(qand)
        elif desired == False and required == False and forbidden == False:
            persona = list(mensajes.find({"sender": int(userid)}))
            return str(persona)

    if desired == False and required == False and not(userid  == False):
        persona = list(mensajes.find({"sender": int(userid)}))
        for elemento in persona:
            for forb in forbidden:
                if forb in str(elemento):
                    if elemento in persona:
                        persona.remove(elemento)
        return str(persona)

    elif desired == False and required == False:
        todo = list(mensajes.find({}))
        for elemento in todo:
            for forb in forbidden:
                if forb in str(elemento):
                    if elemento in todo:
                        todo.remove(elemento)
        return str(todo)

    resultado = list(mensajes.find({"$text":{"$search": query}}))
    return str(resultado)

@app.route("/messages/<int:mid>")
def get_message(mid):
    '''
    Obtiene el mensaje de id entregada
    '''
    resultado = list(mensajes.find({"mid": mid}, {"_id": 0}))
    if len(resultado) == 0:
        return "<h1>El mensaje que esta buscando no existe.</h1>"
    if json.jsonify(resultado):
        return json.jsonify(resultado)

@app.route("/messages", methods=['POST'])
def create_message():

    message = {'message': request.json['message']}
    sender = {'sender': request.json['sender']}
    receptant ={'receptant': request.json['receptant']}
    lat = {'lat': request.json['lat']}
    longitud = {'long': request.json['long']}
    date = {'date': request.json['date']}

    if message and sender and receptant and lat and longitud and date:
        x = 0
        while x==0:
            mid = random.randint(1,10000000)
            resultado = list(mensajes.find({"mid": mid}, {"_id": 0}))
            if len(resultado) == 0:
                data ={
                    "mid":mid,
                    "date":date,
                    "lat":lat,
                    "long":longitud,
                    "message":message,
                    "receptant":receptant,
                    "sender":sender
                    }
                resultado = mensajes.insert_one(data)
                x=1

                return "<h1>El siguiente mensaje se creo:" + str(data) + "</h1>"

    else:
        return "<h1>El mensaje NO se creo.</h1>"



if __name__ == "__main__":
    app.run(debug=True)
    # app.run(debug=True) # Para debuggear!
# ¡Mucho ánimo y éxito! ¡Saludos! :D
